import java.util.Scanner; 
import java.awt.Point;
import java.text.DecimalFormat;

class Main {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    DecimalFormat formatter = new DecimalFormat("#.##");
    System.out.println("Welcome to the linear equation program, please enter a set of coordinates to calculate the linear equation. Please follow the format of (x, y)");
    
    //first pair of coordinates are entered below and x and y values are extracted from the coordinate using substring and parseInt. 
    String cords = scan.nextLine();
    int commaLoc = cords.indexOf(","); 
    int x1 = Integer.parseInt(cords.substring(1,commaLoc));
    int y1 = Integer.parseInt(cords.substring(commaLoc + 2, cords.length() - 1)); 

    //second pair of coordinates are entered below and x and y values are extracted from the coordinate using substring and parseInt. 
    System.out.println("Now enter a second pair of coordinates"); 
    String cords2 = scan.nextLine(); 
    int commaLoc2 = cords2.indexOf(","); 
    int x2 = Integer.parseInt(cords2.substring(1,commaLoc2));
    int y2 = Integer.parseInt(cords2.substring(commaLoc2 + 2, cords2.length() - 1)); 

    if (x1 == x2) { //if x1 = x2 (the line is vertical), the program will print the below message and terminate. 
      if (x1 == 1) System.out.println("Your line is vertical, its equation is y = x");
      else System.out.println("Your line is vertical, its equation is y = " + x1 + "x" );
    }
    else { //if x1 != x2, the line is not vertical, the program continues below. 

    LinearEquation lin1 = new LinearEquation(x1, y1, x2, y2); //constructs linear equation object
    System.out.println("Equation: " + lin1.equation()); 
    System.out.println("The slope is " + lin1.slope()); 
    System.out.println("Y-intercept: " + lin1.yIntercept()); 
    System.out.println("Distance: " + lin1.distance()); 
    System.out.println("--------LINE INFO--------");
    System.out.println(lin1.lineInfo()); 
      


//
    System.out.println("Please enter an x value for which you want to find corresponding y value for in the equation. ");
    double cordx = scan.nextDouble(); 
   System.out.println("The coordinate for your inputted x is " + lin1.coordinateForX(cordx)); 
    
    
    
    
    }   
  }
}