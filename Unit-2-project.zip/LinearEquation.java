import java.text.DecimalFormat;
public class LinearEquation {
  DecimalFormat formatter = new DecimalFormat("#.##");


  private int x1;
  private int y1;
  private int x2;
  private int y2; 


  
  public LinearEquation(int x1, int y1, int x2, int y2) {
    this.x1 = x1;
    this.y1 = y1;
    this.x2 = x2;
    this.y2 = y2; 
    }
  
  public double distance() {
    double xLeg = Math.abs(x1-x2); 
    double yLeg = Math.abs(y1-y2);
    double squared = Math.pow(xLeg, 2) + Math.pow(yLeg, 2); 
    double finalDistance = Math.sqrt(squared); 
    return roundedToHundredth(finalDistance); 
  }

  public double yIntercept() {
    double run = x2 - x1; 
    double rise = y2 - y1; 
    double slope = rise / run; 
    double negativeSlope = slope - slope * 2;
    double yint = negativeSlope * x1 + y1; //here, I algebraically manipulated the y = mx + b equation into b = -mx + y in order to solve for b, the y-intercept. 
    return roundedToHundredth(yint); 
  }


  
  public String slopeForDisplayInEquation() { //this method returns the slope as a string that can be integrated as a fraction into the final equation. THE ORIGINAL SLOPE METHOD THAT RETURNS A DOUBLE IS STILL IN MY PROGRAM. I know that according to the rubric, I cannot change any of the required methods, so I made this new method to display the slope as a fraction if needed. I'm still using the other method to return the slope as a double for display in lineInfo. 
    double run = (x2-x1); 
    double rise = (y2-y1); 
    double slope = 0; 
    String slopeS = ""; //slope stored in string form
    String slopeFraction = ""; //fractional slope (if applicable) stored in string form
    if (rise % run == 0) { //if rise over run divides perfectly into a whole number slope, that slope is stored as a string value and returned, I have found that the only way to integrate it into the equation is to return it as a string value. 
      slope = (rise / run);
      int slopeInt = (int)slope; 
      slopeS= Integer.toString(slopeInt); 
      return slopeS; } 
    
    if (rise % run != 0) { //if rise over run divides into a decimal, then they will be represented as a fraction in string form. 
      slopeFraction = (int)rise + "/" + (int)run; 
      if(rise < 0 && run <0) { //if both rise and run are negative, then the fraction will be displayed with the negative signs removed. Since two negatives make positive. 
        return (int)Math.abs(rise) + "/" + (int)Math.abs(run);
      }
      if (rise < 0 || run <0) { //if either rise or run is negative, the negatve sign will be placed in front of the whole fraction. 
        return "-" + (int)Math.abs(rise) + "/" + (int)Math.abs(run); 
      }
    return slopeFraction; //returns slope fraction in string form. 
    } 
  return ""; //this is here to prevent the "missing return statement" error. 
  }



  
  public double slope() { //this method returns the slope calculated as a double for use in lineInfo method
    double run = (x2-x1); 
    double rise = (y2-y1);
    return roundedToHundredth(rise / run); 
  }

  public String equation() {
    
    if (slope() == 0) return "y = " + y1; //returns just y = *value* if slope is zero. 
    if (slope() == 1 && yIntercept() == 0) return "y = x"; 
    if (slope() == -1 && yIntercept() == 0) return "y = -x"; 
    if (slope() == -1) return "y = -x" + " + " + yIntercept(); 
    if (yIntercept() == 0)  return "y = " + slopeForDisplayInEquation() + "x "; //if y-intercept is zero, the equation will only display the slope. 
    if (yIntercept() > 0) { //if y-intercept is positive, then it will be displayed with the addition sign. 
      if (slope() == 1) return "y = x" + " + " + yIntercept(); 
      else {
      return "y = " + slopeForDisplayInEquation() + "x " + " + " + yIntercept() ;} }
  
    else if (yIntercept() < 0) { //if y-intercept is negative, it won't be displayed with an addition sign since it already has a subtraction sign. 
      return "y = " + slopeForDisplayInEquation() + "x " +  yIntercept() ;
    }
  return null; 
  }

  
  public double roundedToHundredth(double toRound) { //the round method does not perfectly round every decimal to the example provided in the test code, but it works. 
    double rounded = toRound;
    rounded = Math.round(rounded * 100.0) / 100.0; //rounds the input to the hundredth place
    return rounded;
}

  
  public String coordinateForX(double xValue) {
    double ycord = xValue * slope() + yIntercept(); //plugs the x into equation to solve for y. 
    return "(" + xValue + ", " + roundedToHundredth(ycord) + ")"; //returns output as a string in coordinate format. 
}

  public String lineInfo() { //prints out all info about the line. 
    
    String pts = "The original points are: (" + x1 + ", " + y1 + ")" + " and (" + x2 + ", " + y2 + ")"; 
    String equationForInfo = "The equation is " + equation() ;
    String slopeForInfo = "The slope is " + slope(); 
    String yintForInfo = "The y-intercept is " + yIntercept();
    String distForInfo = "The distance of the line is " + distance();
    return pts + "\n" + equationForInfo + "\n" + slopeForInfo + "\n" + yintForInfo + "\n" + distForInfo + "\n" ; //concats the strings and uses escape characters to separate them into different rows. 
  }

}
       
  

  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
 /* 
  public String displayCords() {
    return cords; 
}
  public int getX() {
    return xValue;
  }

  public int getY() {
    return yValue; 
  } 







  */

